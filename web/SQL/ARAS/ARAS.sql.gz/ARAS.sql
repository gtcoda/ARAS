-- MySQL dump 10.13  Distrib 5.7.36, for Linux (x86_64)
--
-- Host: localhost    Database: ARAS
-- ------------------------------------------------------
-- Server version	5.7.36-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `event_id` int(64) NOT NULL AUTO_INCREMENT,
  `machine_id` int(64) NOT NULL,
  `user_id` int(64) NOT NULL,
  `repair_id` int(64) NOT NULL,
  `event_data` datetime NOT NULL,
  `event_message` text NOT NULL,
  `event_modif_1` int(64) NOT NULL,
  `event_modif_2` int(64) NOT NULL,
  `event_modif_3` int(64) NOT NULL,
  PRIMARY KEY (`event_id`),
  KEY `machine_id` (`machine_id`),
  KEY `user_id` (`user_id`),
  KEY `event_modif_1` (`event_modif_1`,`event_modif_2`,`event_modif_3`),
  KEY `event_modif_2` (`event_modif_2`),
  KEY `event_modif_3` (`event_modif_3`),
  KEY `repair_id` (`repair_id`),
  CONSTRAINT `events_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE,
  CONSTRAINT `events_ibfk_2` FOREIGN KEY (`event_modif_1`) REFERENCES `modifiers` (`modifier_id`) ON UPDATE CASCADE,
  CONSTRAINT `events_ibfk_3` FOREIGN KEY (`event_modif_2`) REFERENCES `modifiers` (`modifier_id`) ON UPDATE CASCADE,
  CONSTRAINT `events_ibfk_4` FOREIGN KEY (`event_modif_3`) REFERENCES `modifiers` (`modifier_id`) ON UPDATE CASCADE,
  CONSTRAINT `events_ibfk_5` FOREIGN KEY (`repair_id`) REFERENCES `repairs` (`repair_id`) ON UPDATE CASCADE,
  CONSTRAINT `events_ibfk_6` FOREIGN KEY (`machine_id`) REFERENCES `machines` (`machine_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Contains all events.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gilds`
--

DROP TABLE IF EXISTS `gilds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gilds` (
  `gild_id` int(64) NOT NULL AUTO_INCREMENT,
  `gild_number` int(64) NOT NULL,
  `gild_name` varchar(255) NOT NULL,
  `gild_desc` text NOT NULL,
  `gild_dimX` int(64) NOT NULL,
  `gild_dimY` int(64) NOT NULL,
  PRIMARY KEY (`gild_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Contains a description of production workshops.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gilds`
--

LOCK TABLES `gilds` WRITE;
/*!40000 ALTER TABLE `gilds` DISABLE KEYS */;
/*!40000 ALTER TABLE `gilds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `machines`
--

DROP TABLE IF EXISTS `machines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `machines` (
  `machine_id` int(64) NOT NULL AUTO_INCREMENT,
  `model_id` int(64) NOT NULL,
  `machine_number` int(64) NOT NULL,
  `gild_id` int(64) NOT NULL,
  `machine_desc` text NOT NULL,
  `machine_posX` int(64) NOT NULL,
  `machine_posY` int(64) NOT NULL,
  PRIMARY KEY (`machine_id`),
  KEY `model_id` (`model_id`),
  KEY `gild_id` (`gild_id`),
  CONSTRAINT `machines_ibfk_2` FOREIGN KEY (`gild_id`) REFERENCES `gilds` (`gild_id`) ON DELETE CASCADE,
  CONSTRAINT `machines_ibfk_3` FOREIGN KEY (`model_id`) REFERENCES `models` (`model_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Contains information about the equipment.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `machines`
--

LOCK TABLES `machines` WRITE;
/*!40000 ALTER TABLE `machines` DISABLE KEYS */;
/*!40000 ALTER TABLE `machines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `models`
--

DROP TABLE IF EXISTS `models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `models` (
  `model_id` int(64) NOT NULL AUTO_INCREMENT,
  `model_name` varchar(255) NOT NULL,
  `model_desc` text NOT NULL,
  PRIMARY KEY (`model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Contains a description of the equipment models.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `models`
--

LOCK TABLES `models` WRITE;
/*!40000 ALTER TABLE `models` DISABLE KEYS */;
/*!40000 ALTER TABLE `models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modifiers`
--

DROP TABLE IF EXISTS `modifiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modifiers` (
  `modifier_id` int(64) NOT NULL AUTO_INCREMENT,
  `modifier_name` varchar(255) NOT NULL,
  `modifier_desc` varchar(255) NOT NULL,
  PRIMARY KEY (`modifier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modifiers`
--

LOCK TABLES `modifiers` WRITE;
/*!40000 ALTER TABLE `modifiers` DISABLE KEYS */;
/*!40000 ALTER TABLE `modifiers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repairs`
--

DROP TABLE IF EXISTS `repairs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repairs` (
  `repair_id` int(64) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`repair_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repairs`
--

LOCK TABLES `repairs` WRITE;
/*!40000 ALTER TABLE `repairs` DISABLE KEYS */;
/*!40000 ALTER TABLE `repairs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `role_id` int(64) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(255) NOT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`role_id`, `role_name`) VALUES (1,'administrator'),(3,'serviceman');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(64) NOT NULL AUTO_INCREMENT,
  `user_login` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `role_id` int(64) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_login` (`user_login`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COMMENT='Contains information about users.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`user_id`, `user_login`, `user_password`, `user_name`, `role_id`) VALUES (4,'gtcoda','$2y$10$FgplVf0lzF03rv0XHAOnMOTefGphGRi5n2wGhTM1EPbbgVz2Yn3ua','Sid',3);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-31 19:02:01
